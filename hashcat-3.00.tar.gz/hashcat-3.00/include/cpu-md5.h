void md5_64 (uint block[16], uint digest[4]);

